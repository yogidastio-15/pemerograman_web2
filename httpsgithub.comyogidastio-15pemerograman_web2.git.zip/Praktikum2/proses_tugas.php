<?php 

$customer = $_GET['customer'];
$jumlah = $_GET['jumlah'];
if($produk_0=="TV")$harga=4200000
if($produk_1=="KULKAS")$harga=3100000
if($produk_2=="MESIN CUCI")$harga=3800000
$total = $jumlah*$harga

?>